NTU watercolor pigments spectral measurement dataset (NTU WPSM dataset), January 2019.




Part A (for DNN):

Input layer:

MQ_test_488_X_ok.csv
MQ_train_1956_X_ok.csv

Output layer:

MQ_test_488_Y_ok.csv
MQ_train_1956_Y_ok.csv


Part B:

The RGB values of primary and mixed pigments are converted by our measurement data (pigment coated on paper).

1. Primary pigments with different quantities.

   PigmentRGB_primary.csv 

2. Mixed pigments with different ratios.
	
   PigmentRGB_mixed_1_1.csv
   PigmentRGB_mixed_1_2.csv
   PigmentRGB_mixed_2_1.csv
